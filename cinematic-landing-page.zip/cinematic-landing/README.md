# Cinematic Landing Page — Vite + React + Scroll-Scrub Canvas

Premium one-page marketing site inspired by Apple/Sony-style launch pages. The hero uses a canvas frame sequence, not a `<video>` element. This project includes a lightweight generated mock frame sequence so `npm run dev` works immediately. Replace it with your real extracted frames for production.

## Stack

- Vite + React 18 + TypeScript
- Tailwind CSS v4 with `@theme`
- shadcn/ui-compatible Button and Accordion
- Motion for React
- lucide-react
- self-hosted `@fontsource/oswald` and `@fontsource/inter`

## Run

```bash
npm install
npm run dev
npm run build
```

## Hero video → JPG frame pipeline

```bash
# 1. Drop the source video at /input/source.mp4 in the project root.
mkdir -p input public/frames

# 2. Extract frames with ffmpeg. Requires ffmpeg installed locally.
ffmpeg -i input/source.mp4 \
  -vf "fps=30,scale='min(1920,iw)':'-2':flags=lanczos" \
  -q:v 3 \
  public/frames/frame_%04d.jpg

# 3. Count the frames and paste the number into FRAME_COUNT in src/lib/constants.ts.
ls public/frames | wc -l

# Optional: convert to WebP for smaller payload.
# for f in public/frames/*.jpg; do
#   cwebp -q 82 "$f" -o "${f%.jpg}.webp" && rm "$f"
# done
```

If your host has a 25 MB deployment limit, check the folder size before deploying:

```bash
du -sh public/frames
```

If the frame folder exceeds ~20 MB, switch to WebP or reduce frame dimensions/FPS.

No ffmpeg locally? A WASM fallback using `@ffmpeg/ffmpeg` can be added as `scripts/extract-frames.mjs`; it is intentionally not implemented here to keep the default app lean.

## Important constants

Edit `src/lib/constants.ts`:

```ts
export const FRAMES_PATH = "/frames";
export const FRAME_COUNT = 240;
export const FRAME_EXT = "jpg" as const;
```

Frame filenames must be zero-padded: `frame_0001.jpg` through `frame_0240.jpg`.

## Notes

- Hero is rendered by `src/components/ScrubSequence.tsx` on a canvas tied to scroll progress.
- `<video>` is used only for Stats and CTA backgrounds.
- `/input` is gitignored.
- Current placeholder brand is `Atelier`; replace copy and constants as needed.
