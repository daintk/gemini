export const FRAMES_PATH = "/frames";
export const FRAME_COUNT = 240;
export const FRAME_EXT = "jpg" as const;
export const LANG = "fr-CH";
export const BRAND_NAME = "Atelier";
export const BRAND_TAGLINE = "Built for what's next";
