import { motion } from "motion/react";
import { ArrowUpRight, Building2, Globe, Package, Sparkles, Truck, Warehouse } from "lucide-react";
import { BlurText } from "@/components/BlurText";

const services = [
  { icon: Truck, title: "Déménagement", body: "Des équipes précises, discrètes et préparées pour les appartements, maisons et adresses sensibles." },
  { icon: Package, title: "Emballage", body: "Protection textile, caisse dédiée et inventaire clair avant chaque départ." },
  { icon: Warehouse, title: "Garde-meubles", body: "Stockage sécurisé, climatisé et accessible sur rendez-vous." },
  { icon: Globe, title: "International", body: "Coordination douanière, transport premium et suivi à chaque frontière." },
  { icon: Building2, title: "Bureaux", body: "Transfert d'entreprise sans rupture, postes, archives et matériel critique compris." },
  { icon: Sparkles, title: "Sur-mesure", body: "Objets d'art, pianos, collections et pièces fragiles traités comme des pièces uniques." },
];

const cardClasses = [
  "md:row-span-2 md:col-span-1 p-8 min-h-[480px]",
  "md:col-span-1 p-6 min-h-[228px]",
  "md:col-span-1 p-6 min-h-[228px]",
  "md:col-span-2 p-7 min-h-[228px]",
  "md:col-span-1 p-6 min-h-[228px]",
  "md:col-span-3 p-7 min-h-[200px]",
];

export function ServicesBento() {
  return (
    <section id="services" className="relative py-28 md:py-40">
      <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)] mb-14">
        <span className="liquid-glass rounded-full px-4 py-1.5 text-xs text-foreground/80">Nos services</span>
        <BlurText text="Tout ce qui bouge. Sous un seul toit." className="font-display uppercase text-5xl md:text-7xl leading-[0.9] tracking-tight mt-5 max-w-[14ch]" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5 max-w-[var(--max)] mx-auto px-[var(--gutter)]">
        {services.map((service, i) => {
          const Icon = service.icon;
          return (
            <motion.div key={service.title} className={`liquid-glass rounded-2xl relative overflow-hidden group ${cardClasses[i]}`} whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 260, damping: 26 }}>
              <div className="liquid-glass-strong rounded-full w-11 h-11 flex items-center justify-center mb-5"><Icon className="size-5 text-foreground" /></div>
              <h3 className="font-display uppercase text-2xl md:text-3xl leading-[0.95] tracking-tight mb-3 max-w-[18ch]">{service.title}</h3>
              <p className="font-body text-sm text-foreground/65 max-w-[38ch] leading-relaxed">{service.body}</p>
              <ArrowUpRight className="absolute top-6 right-6 size-5 text-foreground/30 group-hover:text-foreground/80 transition-colors" />
              <div className="absolute -right-16 -bottom-20 h-44 w-44 rounded-full bg-primary/10 blur-3xl" />
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
