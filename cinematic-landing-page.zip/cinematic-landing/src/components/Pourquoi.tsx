import { Award, Clock, Leaf, ShieldCheck } from "lucide-react";
import { BlurText } from "@/components/BlurText";

const reasons = [
  { icon: ShieldCheck, title: "Assuré intégralement", body: "Chaque mission est couverte, inventoriée et documentée avant le premier carton." },
  { icon: Clock, title: "Ponctuels", body: "Des créneaux réalistes, une équipe dédiée et une communication claire le jour J." },
  { icon: Leaf, title: "Éco-conscients", body: "Matériaux réutilisables, trajets optimisés et partenaires locaux quand c'est possible." },
  { icon: Award, title: "Certifiés Swiss Moving", body: "Méthodes éprouvées, personnel formé et standards premium pour les adresses exigeantes." },
];

export function Pourquoi() {
  return (
    <section id="pourquoi" className="relative py-28 md:py-40 border-t border-border/40">
      <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)] text-center">
        <span className="liquid-glass rounded-full px-4 py-1.5 text-xs text-foreground/80">Pourquoi nous</span>
        <BlurText text="La précision calme." className="font-display uppercase text-4xl md:text-6xl leading-[0.9] max-w-[18ch] mx-auto text-center tracking-tight mt-5" />
        <p className="font-body text-foreground/65 max-w-2xl mx-auto mt-5">Une logistique premium doit se sentir simple, stable et parfaitement maîtrisée.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mt-16 max-w-[var(--max)] mx-auto px-[var(--gutter)]">
        {reasons.map((reason) => {
          const Icon = reason.icon;
          return (
            <div key={reason.title} className="liquid-glass rounded-2xl p-7 flex flex-col gap-5 min-h-[260px]">
              <div className="liquid-glass-strong rounded-full w-11 h-11 flex items-center justify-center"><Icon className="size-5" /></div>
              <h3 className="font-display uppercase text-xl tracking-tight">{reason.title}</h3>
              <p className="font-body text-sm text-foreground/65 leading-relaxed">{reason.body}</p>
              <div className="mt-auto h-px w-10 bg-gradient-to-r from-primary to-transparent" />
            </div>
          );
        })}
      </div>
    </section>
  );
}
