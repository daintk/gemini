import { useEffect, useState } from "react";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "motion/react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BRAND_NAME } from "@/lib/constants";

const navItems = [
  { label: "Services", href: "#services" },
  { label: "Pourquoi", href: "#pourquoi" },
  { label: "Processus", href: "#process" },
  { label: "Avis", href: "#testimonials" },
  { label: "FAQ", href: "#faq" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("#services");
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => setScrolled(latest > 40));

  useEffect(() => {
    const observers = navItems.map((item) => {
      const el = document.querySelector(item.href);
      if (!el) return null;
      const io = new IntersectionObserver(([entry]) => {
        if (entry.isIntersecting) setActive(item.href);
      }, { rootMargin: "-40% 0px -55% 0px" });
      io.observe(el);
      return io;
    });
    return () => observers.forEach((io) => io?.disconnect());
  }, []);

  return (
    <motion.header
      data-scrolled={scrolled}
      animate={{ top: scrolled ? 8 : 16 }}
      className="fixed left-1/2 z-50 w-[min(1200px,calc(100vw-32px))] -translate-x-1/2"
    >
      <div className="liquid-glass rounded-full px-2 py-2 flex items-center justify-between gap-4 data-[scrolled=true]:backdrop-blur-xl" data-scrolled={scrolled}>
        <a href="#" className="flex items-center gap-2 pl-3 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-full">
          <img src="/logo.svg" alt="" className="h-6 w-auto" />
          <span className="font-display text-lg tracking-tight">{BRAND_NAME}</span>
        </a>
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <a key={item.href} href={item.href} className={`relative px-3.5 py-2 text-sm transition-colors font-body ${active === item.href ? "text-foreground" : "text-foreground/80 hover:text-foreground"}`}>
              {item.label}
              {active === item.href && <span className="absolute bottom-1 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-primary" />}
            </a>
          ))}
        </nav>
        <div className="hidden md:block">
          <Button variant="heroSolid" size="sm" className="rounded-full px-4 py-1.5 text-sm" asChild>
            <a href="#cta">Get Started <ArrowUpRight className="ml-1 size-4" /></a>
          </Button>
        </div>
        <button aria-label="Ouvrir le menu" className="md:hidden liquid-glass-strong rounded-full h-10 w-10 flex items-center justify-center" onClick={() => setOpen(true)}>
          <Menu className="size-5" />
        </button>
      </div>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[60] md:hidden">
            <div className="absolute inset-0 bg-background/70" onClick={() => setOpen(false)} />
            <motion.div initial={{ y: -24, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -24, opacity: 0 }} className="liquid-glass-strong m-4 rounded-3xl p-6">
              <div className="flex items-center justify-between">
                <span className="font-display text-2xl">{BRAND_NAME}</span>
                <button aria-label="Fermer le menu" className="rounded-full h-10 w-10 flex items-center justify-center" onClick={() => setOpen(false)}><X className="size-5" /></button>
              </div>
              <nav className="mt-8 flex flex-col gap-2">
                {navItems.map((item) => <a key={item.href} href={item.href} onClick={() => setOpen(false)} className="font-display uppercase text-4xl tracking-tight py-2">{item.label}</a>)}
              </nav>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
