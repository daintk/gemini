import { animate, motion, useInView, useMotionValue, useTransform } from "motion/react";
import { useEffect, useRef } from "react";
import { VideoBackground } from "@/components/VideoBackground";

const stats = [
  { value: "2500+", label: "Déménagements" },
  { value: "98%", label: "Clients satisfaits" },
  { value: "24h", label: "Délai de devis" },
  { value: "15 ans", label: "Métier" },
];

function StatValue({ value }: { value: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.4 });
  const numeric = Number(value.match(/\d+/)?.[0] ?? 0);
  const suffix = value.replace(String(numeric), "");
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (latest) => `${Math.round(latest)}${suffix}`);
  useEffect(() => {
    if (inView && numeric > 0) {
      const controls = animate(mv, numeric, { duration: 1.1, ease: [0.22, 1, 0.36, 1] });
      return controls.stop;
    }
  }, [inView, mv, numeric]);
  return <motion.span ref={ref}>{rounded}</motion.span>;
}

export function Stats() {
  return (
    <section className="relative py-32 md:py-44 overflow-hidden">
      <VideoBackground src="/stats-bg.mp4" className="absolute inset-0 w-full h-full object-cover filter saturate-0 opacity-35" />
      <div className="absolute top-0 inset-x-0 h-[200px] gradient-fade-t" />
      <div className="absolute bottom-0 inset-x-0 h-[200px] gradient-fade-b" />
      <div className="liquid-glass rounded-3xl p-10 md:p-14 mx-[var(--gutter)] max-w-[var(--max)] md:mx-auto relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12 relative">
          {[1, 2, 3].map((n) => <div key={n} className="hidden md:block absolute top-1/2 -translate-y-1/2 w-px h-12 bg-border" style={{ left: `${n * 25}%` }} />)}
          {stats.map((stat) => (
            <div key={stat.label}>
              <div className="font-display italic text-5xl md:text-6xl lg:text-7xl leading-none text-foreground"><StatValue value={stat.value} /></div>
              <div className="font-body text-sm text-foreground/60 mt-3 tracking-wide uppercase">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
