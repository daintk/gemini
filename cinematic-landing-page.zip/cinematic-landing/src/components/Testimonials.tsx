import { Quote } from "lucide-react";
import { BlurText } from "@/components/BlurText";

const testimonials = [
  { quote: "Tout était silencieux, précis et parfaitement anticipé. Une expérience rare.", name: "Claire Monnier", role: "Collection privée" },
  { quote: "Ils ont déplacé nos bureaux sans interrompre une seule journée d'activité.", name: "Marc Keller", role: "COO, Maison K" },
  { quote: "Le niveau d'attention aux objets fragiles dépasse ce que nous avions imaginé.", name: "Nadia Favre", role: "Architecte" },
  { quote: "Ponctuels, élégants, calmes. Exactement ce que l'on attend d'un service premium.", name: "Thomas Ried", role: "Client privé" },
  { quote: "Le devis était clair, l'équipe encore plus claire. Rien à redire.", name: "Sophie Blanc", role: "Fondatrice" },
  { quote: "Notre transfert international a été géré comme une production de luxe.", name: "Luca Moretti", role: "Galeriste" },
];

function Card({ quote, name, role }: { quote: string; name: string; role: string }) {
  return (
    <div className="liquid-glass rounded-2xl p-7 w-[340px] md:w-[400px] shrink-0 flex flex-col gap-5">
      <Quote className="size-5 text-primary/70" />
      <p className="font-body text-foreground/85 italic leading-relaxed text-[15px]">{quote}</p>
      <div className="mt-auto flex items-center gap-3">
        <div className="size-9 rounded-full bg-gradient-to-br from-primary/60 to-secondary/60" />
        <div><div className="font-body font-medium text-sm">{name}</div><div className="font-body text-xs text-foreground/55 uppercase tracking-wide">{role}</div></div>
      </div>
    </div>
  );
}

export function Testimonials() {
  const shifted = [...testimonials.slice(3), ...testimonials.slice(0, 3), ...testimonials.slice(3), ...testimonials.slice(0, 3)];
  return (
    <section id="testimonials" className="relative py-28 md:py-40">
      <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)]">
        <span className="liquid-glass rounded-full px-4 py-1.5 text-xs text-foreground/80">Témoignages</span>
        <BlurText as="h2" text="Ils parlent mieux que nous." className="font-display uppercase text-5xl md:text-7xl leading-[0.9] tracking-tight mt-5 max-w-[14ch]" />
      </div>
      <div className="group relative mt-16 flex flex-col gap-5 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]">
        <div className="flex gap-5 w-max animate-[var(--animate-marquee)] group-hover:[animation-play-state:paused]">{[...testimonials, ...testimonials].map((t, i) => <Card key={`a-${i}`} {...t} />)}</div>
        <div className="flex gap-5 w-max animate-[var(--animate-marquee-rev)] group-hover:[animation-play-state:paused]">{shifted.map((t, i) => <Card key={`b-${i}`} {...t} />)}</div>
      </div>
    </section>
  );
}
