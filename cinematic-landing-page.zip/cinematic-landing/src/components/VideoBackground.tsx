import { useEffect, useRef } from "react";

type Props = { src: string; className?: string };

export function VideoBackground({ src, className }: Props) {
  const ref = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = ref.current;
    if (!video || !src.endsWith(".m3u8")) return;
    let hls: import("hls.js").default | null = null;
    import("hls.js").then(({ default: Hls }) => {
      if (Hls.isSupported()) {
        hls = new Hls();
        hls.loadSource(src);
        hls.attachMedia(video);
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = src;
      }
    });
    return () => hls?.destroy();
  }, [src]);

  return <video ref={ref} src={src.endsWith(".m3u8") ? undefined : src} autoPlay loop muted playsInline className={className} />;
}
