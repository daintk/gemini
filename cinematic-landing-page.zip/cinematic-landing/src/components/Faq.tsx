import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { BlurText } from "@/components/BlurText";

const items = [
  { q: "Combien de temps dure un devis ?", a: "Un premier devis peut être établi en 24 heures après l'échange initial, puis affiné après visite ou inventaire détaillé." },
  { q: "Prenez-vous en charge l'emballage ?", a: "Oui. Nous préparons les cartons, protections textiles, caisses spécifiques et inventaires selon le niveau de service choisi." },
  { q: "Les objets fragiles sont-ils assurés ?", a: "Chaque mission inclut une couverture adaptée. Les objets de valeur font l'objet d'un protocole séparé et documenté." },
  { q: "Travaillez-vous à l'international ?", a: "Oui. Nous coordonnons transport, douane et livraison finale avec des partenaires spécialisés." },
  { q: "Pouvez-vous gérer un transfert d'entreprise ?", a: "Oui. Nous planifions par zones, équipes et contraintes d'exploitation pour limiter l'interruption." },
  { q: "Proposez-vous du stockage ?", a: "Oui. Les biens peuvent être conservés en garde-meubles sécurisé, avec accès organisé sur rendez-vous." },
];

export function Faq() {
  return (
    <section id="faq" className="relative py-28 md:py-40">
      <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)] grid grid-cols-1 md:grid-cols-[0.9fr_1.1fr] gap-16">
        <div className="md:sticky md:top-24 md:self-start">
          <span className="liquid-glass rounded-full px-4 py-1.5 text-xs text-foreground/80">FAQ</span>
          <BlurText as="h2" text="Questions fréquentes." className="font-display uppercase text-5xl md:text-6xl leading-[0.9] tracking-tight mt-4" />
          <p className="font-body text-foreground/65 mt-6 max-w-sm">Une question plus spécifique ? Nous revenons avec un plan clair, sans jargon.</p>
          <Button variant="heroGlass" className="mt-8">Nous contacter</Button>
        </div>
        <Accordion type="single" collapsible>
          {items.map((item, i) => (
            <AccordionItem key={item.q} value={`item-${i}`} className="border-border/40">
              <AccordionTrigger className="font-display uppercase text-lg md:text-xl tracking-tight py-6 hover:no-underline data-[state=open]:text-primary text-left">
                {item.q}
              </AccordionTrigger>
              <AccordionContent className="font-body text-foreground/70 text-[15px] leading-relaxed pb-6 max-w-[60ch]">
                {item.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
