import { ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BlurText } from "@/components/BlurText";
import { VideoBackground } from "@/components/VideoBackground";
import { BRAND_NAME } from "@/lib/constants";

const footerLinks = [
  { label: "Mentions", href: "/legal" },
  { label: "Confidentialité", href: "/privacy" },
  { label: "Carrières", href: "/careers" },
  { label: "Contact", href: "#cta" },
];

export function CtaFooter() {
  return (
    <section id="cta" className="relative min-h-[100vh] flex flex-col items-center justify-center overflow-hidden">
      <VideoBackground src="/cta-bg.mp4" className="absolute inset-0 w-full h-full object-cover filter brightness-[0.55] opacity-50" />
      <div className="absolute top-0 inset-x-0 h-[200px] gradient-fade-t" />
      <div className="absolute bottom-0 inset-x-0 h-[200px] gradient-fade-b" />
      <div className="relative z-10 px-6 flex flex-col items-center justify-center pt-28">
        <BlurText as="h2" text="Ready to move?" className="font-display italic text-[clamp(56px,10vw,180px)] leading-[0.88] tracking-[-0.02em] text-center max-w-[16ch]" />
        <p className="mt-8 font-body text-base md:text-lg text-foreground/75 max-w-xl text-center">One call. Done.</p>
        <div className="mt-10 flex items-center gap-3 flex-wrap justify-center">
          <Button variant="hero">Get Started <ArrowUpRight className="ml-1 size-4" /></Button>
          <Button variant="heroGlass">Nos tarifs</Button>
        </div>
      </div>
      <div className="relative z-10 w-full border-t border-border/40 mt-auto">
        <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)] py-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <span className="font-body text-xs text-foreground/50">© 2026 {BRAND_NAME}. All rights reserved.</span>
          <nav className="flex items-center gap-6 flex-wrap justify-center">
            {footerLinks.map((l) => <a key={l.href} href={l.href} className="font-body text-xs text-foreground/50 hover:text-foreground/80 transition-colors">{l.label}</a>)}
          </nav>
        </div>
      </div>
    </section>
  );
}
