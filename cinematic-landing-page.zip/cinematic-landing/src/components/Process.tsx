import { motion } from "motion/react";
import { BlurText } from "@/components/BlurText";

const steps = [
  { n: "1", title: "Écouter", body: "Un échange court pour comprendre le volume, les accès, les délais et les contraintes sensibles." },
  { n: "2", title: "Composer", body: "Un plan de déménagement détaillé, lisible et validé avant l'intervention." },
  { n: "3", title: "Exécuter", body: "Une équipe coordonnée arrive, protège, transporte et installe avec méthode." },
  { n: "4", title: "Finaliser", body: "Contrôle, placement final et remise propre pour que le lieu soit immédiatement utilisable." },
];

export function Process() {
  return (
    <section id="process" className="relative py-28 md:py-40 border-t border-border/40">
      <div className="max-w-[var(--max)] mx-auto px-[var(--gutter)] mb-16">
        <span className="liquid-glass rounded-full px-4 py-1.5 text-xs text-foreground/80">Processus</span>
        <BlurText text="Quatre mouvements. Aucun bruit." className="font-display uppercase text-5xl md:text-7xl leading-[0.9] tracking-tight mt-5 max-w-[14ch]" />
      </div>
      <div className="liquid-glass rounded-3xl max-w-[var(--max)] mx-[var(--gutter)] md:mx-auto overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-0 relative">
          {steps.map((step, i) => (
            <motion.div key={step.n} initial={{ opacity: 0, y: 16, filter: "blur(8px)" }} whileInView={{ opacity: 1, y: 0, filter: "blur(0)" }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 0.7, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }} className="relative px-6 md:px-10 py-10 md:py-14 flex flex-col gap-4 items-start">
              {i < steps.length - 1 && <div className="absolute top-20 right-0 h-px w-full bg-gradient-to-r from-border via-border to-transparent hidden md:block" />}
              <span className="font-display text-[96px] md:text-[140px] leading-none text-primary/25 -mb-6 select-none">{step.n.padStart(2, "0")}</span>
              <h3 className="font-display uppercase text-2xl md:text-3xl tracking-tight">{step.title}</h3>
              <p className="font-body text-sm text-foreground/65 leading-relaxed max-w-[30ch]">{step.body}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
